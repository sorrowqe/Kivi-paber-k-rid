import tkinter as tk
import random
import sqlite3

# Create a connection to the database
conn = sqlite3.connect('game_results.db')
c = conn.cursor()

# Create a table to store the game results
c.execute('''CREATE TABLE IF NOT EXISTS game_results
             (id INTEGER PRIMARY KEY AUTOINCREMENT, 
              player_choice TEXT, 
              bot_choice TEXT, 
              result TEXT)''')
conn.commit()

# Define the game logic
def play_game(player_choice):
    # Generate a random choice for the bot
    bot_choices = ['Kivi', 'Paber', 'Käärid']
    bot_choice = random.choice(bot_choices)
    
    # Determine the winner
    if player_choice == bot_choice:
        result = 'Viik'
    elif (player_choice == 'Kivi' and bot_choice == 'Käärid') or \
         (player_choice == 'Paber' and bot_choice == 'Kivi') or \
         (player_choice == 'Käärid' and bot_choice == 'Paber'):
        result = 'Võit'
    else:
        result = 'Kaotus'
    
    # Insert the game result into the database
    c.execute("INSERT INTO game_results (player_choice, bot_choice, result) VALUES (?, ?, ?)",
              (player_choice, bot_choice, result))
    conn.commit()
    
    # Display the result on the GUI
    result_label.config(text='Sina valisid: {}\nBot valis: {}\nTulemus: {}'.format(player_choice, bot_choice, result))

# Create the GUI
root = tk.Tk()
root.title('Kivi, Paber, Käärid')

# Add labels and buttons to the GUI
title_label = tk.Label(root, text='Kivi, Paber, Käärid', font=('Arial', 24))
title_label.pack()

result_label = tk.Label(root, text='', font=('Arial', 18))
result_label.pack()

rock_button = tk.Button(root, text='Kivi', command=lambda: play_game('Kivi'))
rock_button.pack()

paper_button = tk.Button(root, text='Paber', command=lambda: play_game('Paber'))
paper_button.pack()

scissors_button = tk.Button(root, text='Käärid', command=lambda: play_game('Käärid'))
scissors_button.pack()

# Start the GUI loop
root.mainloop()
